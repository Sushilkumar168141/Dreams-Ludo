<?php include('session.php'); ?>
<?php include('public/menubar.php'); ?>
<style>
	.rounded-image {
	  border-radius: 50%;
	}
</style>
<?php include('public/table-reg-user.php'); ?>
<?php include('public/footer.php'); ?>